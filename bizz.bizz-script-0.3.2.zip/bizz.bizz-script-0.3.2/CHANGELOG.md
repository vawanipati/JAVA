# Change Log

## v0.3.2 (March 2024)

* Fixes and updates of the recognized types and their methods.
* Fix of the code snippet for `if`-statements.

## v0.3.1 (November 2023)

* Some fixes and improvements to the recognized types and their methods.

## v0.3.0 (June 2023)

* Script validation rules: You may now encounter the following error messages and warnings:
  * Array operator '[]' is only allowed on values of type List, Index and String.
  * A second loop variable is only allowed when traversing collections of type Index or Structure.
  * Missing parentheses: '...' is a function.
  * Invalid number of arguments for constructor '...'.
  * Expected .. argument(s), but got ...
  * Duplicate function definition '...'.
  * Function definitions are only allowed at the top-level of a script.
  * Variable '...' is never used locally.
  * Function '...' requires 'byref' parameter .. to be an existing variable.
  * Byref Parameter '...' is never assigned or used in the function body.
  * Missing parentheses: '...' is a method, not a field.
  * Unexpected parentheses: '...' is a field, not a method.
  * Unreachable code.
  * The import alias '...' is never used.
  * Unknown internal object name '...'. Did you mean "..."?
  * Unknown external object name '...'. Did you mean "..."?
  * Cannot infer type due to recursive definition of '...'

* Improved scoping for structure fields
* Improved handling of JSDoc comments (error recovery, code completion, optional type annotations)
* Library updates

## v0.2.1 (May 2023)

* Fixed poor error recovery after wrong script parameter declaration
* Improved code completion for type references
* Added validation for type references and parameter declarations

## v0.2.0 (May 2023)

* Support for parameter declarations at the beginning of viewpoint scripts. Use the following syntax to declare the script's parameters:
```ts
/// @param {Object} obj // some object
/// @param {String} str // a string value
/// @param anyThing     // a variable with Unknown type
``` 

* Support for JSDoc-style comments and annotations before variable assignments and function definitions. These annotations help the editor to infer the type of variables to get better code completion. A JSDoc comment is a multi-line comment starting with '/**'. The following JSDoc annotations are supported:
  * @type - to declare the type of a variable
  * @param - to declare the type of a function parameter
  * @returns - to declare the return type of a function
  * @deprecated - to indicate that a function is deprecated
  * @link - to reference other elements in the script

  Example:
  ```ts
  /**
   * Function to greet someone.
   * @param {String} somebody
   * @returns {String}
   */
  function sayHello(somebody)
  {
    output "Hello " + somebody;
  }
  ```

* Minor improvements to reference resolution and code completion.
* Minor improvements to syntax highlighting.

## v0.1.0 (April 2023)

* Initial release
