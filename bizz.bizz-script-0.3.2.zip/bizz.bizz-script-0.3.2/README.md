# Bizzdesign Scripting Support

This extension provides an editor for scripts that can be executed in Bizzdesign Enterprise Studio.

Contributed features:
 * Syntax highlighting
 * Code completion
 * Go to definition
 * Find references
 * Type inferencing on hover
 * JSDoc annotations
 * Validation

